package Models;

import java.io.Serializable;

public class Representative extends User implements Serializable{
	
	//Attributes

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	//Attributes
	private int repStaffID;
	
	//Default Constructor
	public Representative()
	{
		super();
		repStaffID = 0000;
	}
	
	//Primary Constructor
	public Representative(String firstName, String lastName, String email, String contactNum, String password, int repStaffID) {
		super(firstName, lastName, email, contactNum, password);
		this.repStaffID = repStaffID;
	}
	

	public Representative(int userID, String firstName, String lastName, String email, String contactNum,String password) {
		super(userID, firstName, lastName, email, contactNum, password);
		// TODO Auto-generated constructor stub
	}

	//Setters & Getters || Mutators & Accessors
	public int getRepStaffID() {
		return repStaffID;
	}

	public void setRepStaffID(int repStaffID) {
		this.repStaffID = repStaffID;
	}

	//toString
	@Override
	public String toString() {
		return "Representative [repStaffID=" + repStaffID + ", getFirstName()=" + getFirstName() + ", getLastName()="
				+ getLastName() + ", getEmail()=" + getEmail() + ", getContactNum()=" + getContactNum()
				+ ", getPassword()=" + getPassword() + "]";
	}
	

}
