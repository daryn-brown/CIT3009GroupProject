package Models;

import java.io.Serializable;
public abstract class  User implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	//Attributes
	private String firstName;
	

	private String lastName;
	
	
	private String email;
	

	private String contactNum;
	

	private String password;
	
	//Default  Constructor
	public User()
	{
//		userID = 0000;
		firstName = "Firstname";
		lastName = "Lastname";
		email = "someemail@example.com";
		contactNum = "(000)-000-0000";
		password = "[0-1][a-z][A-Z]";
		
	}

		
	//Parameterized Constructor
	public User(int userID, String firstName, String lastName, String email, String contactNum, String password) 
	{
//		this.userID = userID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.contactNum = contactNum;
		this.password = password;
	}
	
	//Parameterized Constructor
		public User(String firstName, String lastName, String email, String contactNum, String password) 
		{
//			this.userID = userID;
			this.firstName = firstName;
			this.lastName = lastName;
			this.email = email;
			this.contactNum = contactNum;
			this.password = password;
		}
//
//	//Setters & Getters || Mutators & Accessors
//	public int getUserID() {
//		return userID;
//	}
//
//
//	public void setUserID(int userID) {
//		this.userID = userID;
//	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getContactNum() {
		return contactNum;
	}


	public void setContactNum(String contactNum) {
		this.contactNum = contactNum;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	@Override
	public String toString() {
		return "User [firstName=" + firstName + ", lastName=" + lastName + ", email=" + email + ", contactNum="
				+ contactNum + ", password=" + password + "]";
	}


//	@Override
//	public String toString() {
//		return "User [userID=" + userID + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email
//				+ ", contactNum=" + contactNum + ", password=" + password + "]";
//	}
	
	

	
}
