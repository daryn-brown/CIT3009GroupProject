package Models;

import java.io.Serializable;

public class Customer extends User implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	//Attributes
	private int customerID;
	

	private String issueType;
	

	private String issueDetails;
	

	//Default  Constructor
	public Customer()
	{
		super();
	    customerID = 0000;;
		issueType = "Technical/Billing/Service/Network";
		issueDetails = "Details of issue(Complaint/Query/Request)";
	}
	
	//Parameterized Constructor
	public Customer(int CustomerID, int userID, String firstName, String lastName, String email, String contactNum, String password, String issueType, String issueDetails)
	{
		super(userID, firstName, lastName, email, contactNum, password);
		this.customerID = CustomerID;
		this.issueType = issueType;
		this.issueDetails = issueDetails;
	}
	
	//Parameterized Constructor catch issueType, issueDetails
	public Customer(String issueType, String issueDetails)
	{
		this.issueType = issueType;
		this.issueDetails = issueDetails;
	}

	//Parameterized  Constructor that catches info for customer being registered
	public Customer(int customerID2, int id, String firstName, String lastName, String email, String contactNum,String password)
	{
		super(id, firstName, lastName, email, contactNum, password);
		this.customerID = customerID2;
	}
	
//	//Parameterized  Constructor that catches info for customer being registered
//	public Customer(int customerID2, int id, String firstName, String lastName, String email, String contactNum)
//	{
//		super(id, firstName, lastName, email, contactNum);
//		this.customerID = customerID2;
//	}
	
	//Parameterized  Constructor that catches info for customer being registered
	public Customer(int customerID2, String firstName, String lastName, String email, String contactNum, String Password)
	{
		super(firstName, lastName, email, contactNum, Password);
		this.customerID = customerID2;
	}

	//Setters & Getters || Mutators & Accessors	
	public int getCustomerID() {
		return customerID;
	}

	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}

	public String getIssueType() {
		return issueType;
	}

	public void setIssueType(String issueType) {
		this.issueType = issueType;
	}

	public String getIssueDetails() {
		return issueDetails;
	}

	public void setIssueDetails(String issueDetails) {
		this.issueDetails = issueDetails;
	}

	@Override
	public String toString() {
		return "Customer [customerID=" + customerID + ", issueType=" + issueType + ", issueDetails=" + issueDetails
				+ ", getFirstName()=" + getFirstName() + ", getLastName()="
				+ getLastName() + ", getEmail()=" + getEmail() + ", getContactNum()=" + getContactNum()
				+ ", getPassword()=" + getPassword() + "]";
	}
	
	
	
}
