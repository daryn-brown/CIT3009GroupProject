package Controller;

import java.util.Scanner;

import Models.Customer;
import Models.Representative;
import Models.Technician;
import GUI.Welcome;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Welcome();
		
		Scanner scanner = new Scanner(System.in);
		 Client client = null;
	        int choice;

	        do {
	            System.out.println("Choose an option:");
	            System.out.println("1. Create Customer");
	            System.out.println("2. Create Technician");
	            System.out.println("3. Create Representative");
	            System.out.println("0. Exit");
	            System.out.print("Enter your choice: ");
	            choice = scanner.nextInt();

	            switch (choice) {
	                case 1:
	                	scanner = new Scanner(System.in);
	        	        System.out.println("Enter the customer details:");
//	        	        System.out.print("userID(Must be between 1 - 999): ");  
//	        	        int id = scanner.nextInt();
//	        	        scanner.nextLine(); // Consume the newline character
	        	        System.out.print("First Name: ");
	        	        String firstName = scanner.nextLine();
	        	        System.out.print("Last Name: ");
	        	        String lastName = scanner.nextLine();
	        	        System.out.print("Email: ");
	        	        String email = scanner.nextLine();
	        	        System.out.print("Contact Number[(000)-000-0000]: ");
	        	        String contactNum = scanner.nextLine();
	        	        System.out.print("Password[(a-z,A-Z,0-9)]: ");
	        	        String password = scanner.nextLine();
	        	        System.out.print("customerID(Must be 5000+): ");
	        	        int customerID = scanner.nextInt();
//	        	       User user = new User(id, firstName, lastName, email, contactNum, password);
	        	      
//	        	       Customer customer = new Customer( customerID, id, firstName, lastName, email, contactNum, password);
	        	       Customer customer = new Customer( customerID,firstName, lastName, email, contactNum, password);
	        	       try {
	        	    	   
	        	    	  client.sendAction("Register Customer");
	   					  client.sendCustomer(customer);
	        	        }catch(Exception ex) {
	        	        	ex.getStackTrace();
	        	        }
					
	                    break;
	                case 2:
//	                    createTechnician();
	                	scanner = new Scanner(System.in);
	        		    System.out.println("Enter the technician's details:");
	        		    System.out.print("First Name: ");
	        		    String firstName1 = scanner.nextLine();
	        		    System.out.print("Last Name: ");
	        		    String lastName1 = scanner.nextLine();
	        		    System.out.print("Email: ");
	        		    String email1 = scanner.nextLine();
	        		    System.out.print("Contact Number[(000)-000-0000]: ");
	        		    String contactNum1 = scanner.nextLine();
	        		    System.out.print("Password[(a-z,A-Z,0-9)]: ");
	        		    String password1 = scanner.nextLine();
	        		    System.out.print("techID(Must be 5000+): ");
	        		    int techID = scanner.nextInt();
	        
	        		    Technician tech = new Technician(techID, firstName1, lastName1, email1, contactNum1, password1); // Set the password here
	        		    try {
	        		    	client.sendAction("Register Technician");
	        		    	client.sendTechnician(tech);
	        		    } catch (Exception ex) {
	        		        ex.printStackTrace();
	        		    }
	                    break;
	                case 3:
	                	
//	                	createRepresentative();
	                    break;
	                case 0:
	                    System.out.println("Exiting...");
	                    break;
	                default:
	                    System.out.println("Invalid choice. Please try again.");
	            }
	        } while (choice != 0);

	        scanner.close();
	}

//	 public static void createCustomer() {
//	        Scanner scanner = new Scanner(System.in);
//	        System.out.println("Enter the customer details:");
////	        System.out.print("userID(Must be between 1 - 999): ");  
////	        int id = scanner.nextInt();
////	        scanner.nextLine(); // Consume the newline character
//	        System.out.print("First Name: ");
//	        String firstName = scanner.nextLine();
//	        System.out.print("Last Name: ");
//	        String lastName = scanner.nextLine();
//	        System.out.print("Email: ");
//	        String email = scanner.nextLine();
//	        System.out.print("Contact Number[(000)-000-0000]: ");
//	        String contactNum = scanner.nextLine();
//	        System.out.print("Password[(a-z,A-Z,0-9)]: ");
//	        String password = scanner.nextLine();
//	        System.out.print("customerID(Must be 5000+): ");
//	        int customerID = scanner.nextInt();
////	       User user = new User(id, firstName, lastName, email, contactNum, password);
//	      
////	       Customer customer = new Customer( customerID, id, firstName, lastName, email, contactNum, password);
//	       Customer customer = new Customer( customerID,firstName, lastName, email, contactNum, password);
//	       try {
//	    	   
//	        	customer.create();
//	        }catch(Exception ex) {
//	        	ex.getStackTrace();
//	        }
//	        
//	        
//
//	        
//	        //return student;
//	    }
//	 
//	 public static void createTechnician() {
//		    Scanner scanner = new Scanner(System.in);
//		    System.out.println("Enter the technician's details:");
//		    System.out.print("First Name: ");
//		    String firstName = scanner.nextLine();
//		    System.out.print("Last Name: ");
//		    String lastName = scanner.nextLine();
//		    System.out.print("Email: ");
//		    String email = scanner.nextLine();
//		    System.out.print("Contact Number[(000)-000-0000]: ");
//		    String contactNum = scanner.nextLine();
//		    System.out.print("Password[(a-z,A-Z,0-9)]: ");
//		    String password = scanner.nextLine();
//		    System.out.print("techID(Must be 5000+): ");
//		    int techID = scanner.nextInt();
//
//		    Technician tech = new Technician(techID, firstName, lastName, email, contactNum, password); // Set the password here
//		    try {
//		        tech.create();
//		    } catch (Exception ex) {
//		        ex.printStackTrace();
//		    }
//		}
//	 
//	 public static void createRepresentative() {
//		    Scanner scanner = new Scanner(System.in);
//		    System.out.println("Enter the representatives' details:");
//		    System.out.print("First Name: ");
//		    String firstName = scanner.nextLine();
//		    System.out.print("Last Name: ");
//		    String lastName = scanner.nextLine();
//		    System.out.print("Email: ");
//		    String email = scanner.nextLine();
//		    System.out.print("Contact Number[(000)-000-0000]: ");
//		    String contactNum = scanner.nextLine();
//		    System.out.print("Password[(a-z,A-Z,0-9)]: ");
//		    String password = scanner.nextLine();
//		    System.out.print("repID(Must be 5000+): ");
//		    int repID = scanner.nextInt();
//
//		    Representative representative = new Representative(repID, firstName, lastName, email, contactNum, password);
//		    try {
//		        representative.create();
//		    } catch (Exception ex) {
//		        ex.printStackTrace();
//		    }
//		}
}
