package Controller;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import javax.swing.JOptionPane;

import Models.Customer;
import Models.Technician;

import java.net.InetAddress;


public class Client {

	private Socket connectionSocket;
	private ObjectOutputStream objOs;
	private ObjectInputStream objIs;
	private String action;
	
	public Client() {
	    // Default constructor
		System.out.println("About to create client connection . . .");
		this.createConnection();
		this.configureStreams();
    }
	
	private void createConnection() {
		try {
	         // Instantiate the connectionSocket variable
			System.out.println("About to create client Socket . . .");
			 connectionSocket = new Socket(InetAddress.getLocalHost(), 8888);
			 System.out.println("client Socket created . . .");
			} catch (IOException e) {
	         // Handle any exceptions here
	         e.printStackTrace();
	     }
	}
	
	 private void configureStreams() {
	        try {
	            // Instantiate the ObjectOutputStream using the connectionSocket's OutputStream
	        	
	            objOs = new ObjectOutputStream(connectionSocket.getOutputStream());
	            // Create an input stream to receive data from the server
	            // Instantiate the ObjectInputStream using the connectionSocket's InputStream
	            objIs = new ObjectInputStream(connectionSocket.getInputStream());
	        } catch (IOException e) {
	            // Handle any exceptions here
	            e.printStackTrace();
	        }
	    }
	 
	 
	 public void closeConnection() {
		 try {
			 objOs.close();
			 objIs.close();
			 connectionSocket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }
	 
	 public void sendAction(String action) {
		 this.action = action;
		 try {
			objOs.writeObject(action);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }
	 
	 public void sendCustomer(Customer Obj) {
		 try {
			objOs.writeObject(Obj);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }
	
	public void sendTechnician(Technician Obj) {
		 try {
			objOs.writeObject(Obj);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }
	 
	 public void receiveResponse() {
	        try {
	            // Process the response accordingly
	            if (action.equalsIgnoreCase("Register Customer")) 
	            {
	                // Handle the flag returned by the server
	               Boolean flag = (Boolean) objIs.readObject();
	               if (flag == null) 
	               {
					JOptionPane.showMessageDialog(null, "Record added successfully", "Add Record Status",
							JOptionPane.INFORMATION_MESSAGE);
	               }
	            }
	            if (action.equalsIgnoreCase("Register Technician")) {
	                Boolean flag = (Boolean) objIs.readObject();
		               if (flag == null) 
		               {
						JOptionPane.showMessageDialog(null, "Record added successfully", "Add Record Status", JOptionPane.INFORMATION_MESSAGE);
		               }
		         }
	        } catch (IOException | ClassCastException | ClassNotFoundException e) {
	            // Handle any exceptions here
	            e.printStackTrace();
	        }
	    }
}
