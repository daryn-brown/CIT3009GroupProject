package Models;

import javax.persistence.*;
import org.hibernate.Session;
import org.hibernate.Transaction;
import Controller.SessionFactoryBuilder;

//Annotate the Java Class
@Entity
@Table(name="representative")
public class Representative extends User{
	
	//Attributes
	@Id
	@Column(name= "repStaffID")
	private int repStaffID;
	
	//Default Constructor
	public Representative()
	{
		super();
		repStaffID = 0000;
	}
	
	//Primary Constructor
	public Representative(String firstName, String lastName, String email, String contactNum, String password, int repStaffID) {
		super(firstName, lastName, email, contactNum, password);
		this.repStaffID = repStaffID;
	}
	

	public Representative(int userID, String firstName, String lastName, String email, String contactNum,String password) {
		super(userID, firstName, lastName, email, contactNum, password);
		// TODO Auto-generated constructor stub
	}

	//Setters & Getters || Mutators & Accessors
	public int getRepStaffID() {
		return repStaffID;
	}

	public void setRepStaffID(int repStaffID) {
		this.repStaffID = repStaffID;
	}

	//toString
	@Override
	public String toString() {
		return "Representative [repStaffID=" + repStaffID + ", getFirstName()=" + getFirstName() + ", getLastName()="
				+ getLastName() + ", getEmail()=" + getEmail() + ", getContactNum()=" + getContactNum()
				+ ", getPassword()=" + getPassword() + "]";
	}
	
	//Creates new representative records
	public void create()
	{
		Session session = null;
		Transaction transaction = null;
		try {
			session = SessionFactoryBuilder.getSessionFactory().getCurrentSession();
			transaction = session.beginTransaction();
			this.setRepStaffID(getRepStaffID());
			this.setFirstName(getFirstName());
			this.setLastName(getLastName());
			this.setEmail(getEmail());
			this.setContactNum(getContactNum());
			this.setPassword(getPassword());
			session.save(this);
			transaction.commit();
			System.out.println("Representative created successfully!");
		} catch (RuntimeException e) {
			if(transaction != null)
			{
				transaction.rollback();
				System.err.println("Representative unable to be created!");
			}
		} finally {
			if(session != null)
			{
				session.close();
			}
		}
	}
}
