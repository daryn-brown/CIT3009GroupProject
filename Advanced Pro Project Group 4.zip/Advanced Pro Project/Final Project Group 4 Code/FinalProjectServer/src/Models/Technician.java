package Models;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.Session;
import org.hibernate.Transaction;

import Controller.SessionFactoryBuilder;

//Annotate the Java Class
@Entity
@Table(name="technician")  //Table name in database
public class Technician extends User{
	
	//Attributes
	@Id
	//@GeneratedValue(strategy=GenerationType.IDENTITY)
	/*Important if multiple objects are to be saved to the database at one time*/
//	@Column(name = "id")
	@Column(name = "techID")
	private int techStaffID;
	
	@Column(name = "availability")
	private String availability;
	
	
	//Default  Constructor
	public Technician()
	{
		super();
		techStaffID = 0000;
		availability = "YES/NO";
	}
	
	//Parameterized Constructor
	public Technician(int techStaffID, int userID, String firstName, String lastName, String email, String contactNum, String password, String availability)
	{
		super(userID, firstName, lastName, email, contactNum, password);
		this.techStaffID = techStaffID;
		this.availability = availability;
	}
	
	//Parameterized Constructor
	public Technician(int techStaffID, String firstName, String lastName, String email, String contactNum, String password)
	{
		super(firstName, lastName, email, contactNum, password);
		this.techStaffID = techStaffID;
//		this.availability = availability;
	}

	//Setters & Getters || Mutators & Accessors
	public int getTechStaffID() {
		return techStaffID;
	}

	public void setTechStaffID(int techStaffID) {
		this.techStaffID = techStaffID;
	}
	
	public String getAvailability() {
		return availability;
	}

	public void setAvailability(String availability) {
		this.availability = availability;
	}

	//toString
	@Override
	public String toString() {
		return "Technician [techStaffID=" + techStaffID + ", availability=" + availability + ", getFirstName()=" + getFirstName() + ", getLastName()=" + getLastName()
				+ ", getEmail()=" + getEmail() + ", getContactNum()=" + getContactNum() + ", getPassword()="
				+ getPassword() + "]";
	}

	public void create() {
	    Session session = null;
	    Transaction transaction = null;
	    try {
	        session = SessionFactoryBuilder.getSessionFactory().getCurrentSession();
	        transaction = session.beginTransaction();

	       
//	        // Now, save the Customer object record
	        

	        this.setPassword(getPassword());
	        this.setTechStaffID(getTechStaffID());
	        this.setFirstName(getFirstName());
	        this.setLastName(getLastName());
	        this.setEmail(getEmail());
	        this.setContactNum(getContactNum());
	        this.setAvailability("YES");
	        session.save(this);
	        
	        //session.save(this);
	        transaction.commit();
	        System.out.println("Technician created successfully!");
	    } catch (RuntimeException e) {
	        if (transaction != null) {
	            transaction.rollback();
	        }
	        e.printStackTrace();
	    } finally {
	        if (session != null) {
	            session.close();
	        }
	    }
	}

}


