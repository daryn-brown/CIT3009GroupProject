package Controller;

import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;


import Models.Customer;
import Models.Technician;

public class Server {

	private ServerSocket serverSocket;
    private Socket connectionSocket;
    private ObjectOutputStream objOs;
    private ObjectInputStream objIs;
    
    
//    public static Connection getDatabaseConnection() 
//	{
//		if (dBConn == null) 
//		{
//			try {
//				String url = "jdbc:mysql://localhost:3306/tcpdblab";//What should be added jdbc:mysql://localhost:3306/dblab
//				dBConn = DriverManager.getConnection(url,"root","");//What should be added url, "root", ""
//				JOptionPane.showMessageDialog(null, "DB Connection Established", "CONNECTION STATUS", JOptionPane.INFORMATION_MESSAGE);// part that has null should be a GUI component
//			} catch (SQLException ex) {
//				System.out.println("not able to connect to mysql/dblab");
//				JOptionPane.showMessageDialog(null, "Could not connect to database\n" + ex, "CONNECTION FAILURE", JOptionPane.ERROR_MESSAGE);// part that has null should be a GUI component 
//			}
//		}
//		return dBConn;
//	}
    
    public Server() {
        // Default constructor
    	 createConnection();
         waitForRequests();
    }

    private void createConnection() {
        // Implementation of the createConnection method goes here
        // Add your code to establish a database connection or perform any necessary setup
    	try {
    		System.out.println("Creating Server Connection . . .");
            serverSocket = new ServerSocket(8888, 1);
            // You can use any valid port number within the valid range
            // Handle the server socket connection setup or any other required operations
            System.out.println("Server socket created successfully on port 8888.");
        } catch (IOException e) {
            System.err.println("Error creating server socket: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void configureStreams() {
        try {
        	//Instantiate the output stream,  using the getOutputStream method 
        	//of the Socket object as argument to the constructor
            objOs = new ObjectOutputStream(connectionSocket.getOutputStream());
            //Instantiate the input stream,  using the getInputStream method 
        	//of the Socket object as argument to the constructor
            objIs = new ObjectInputStream(connectionSocket.getInputStream());
            System.out.println("Streams configured successfully.");
        } catch (IOException e) {
            System.err.println("Error configuring streams: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    
    private void closeConnection() {
        try {
            if (objOs != null)
                objOs.close();
            if (objIs != null)
                objIs.close();
            if (connectionSocket != null)
                connectionSocket.close();
//            if (serverSocket != null)
//                serverSocket.close();
            System.out.println("Connections closed successfully.");
        } catch (IOException e) {
            System.err.println("Error closing connections: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void waitForRequests() {
    	String action = "";
//    	getDatabaseConnection();
//    	Student stuObj = null;
    	Customer customer = null;
    	Technician technician = null;
    	
    	//System.out.println("Waiting for requests . . . ");
        try {

            while (true) {
            	System.out.println("Waiting for request...");
                connectionSocket = serverSocket.accept();
                System.out.println("Client connected: " + connectionSocket.getInetAddress().getHostName());
                this.configureStreams();
                try {
    				action = (String) objIs.readObject();
    				
    				if(action.equals("Register Customer"))
    				{
    					
    					customer = (Customer) objIs.readObject();
    					System.out.println("Customer Record received");
    					customer.create();
    					objOs.writeObject(true);
    				//	this.closeConnection();
    				} else if (action.equals("Register Technician")) {
//    					String tecnician = (String) objIs.readObject();
    					
    					
    					technician = (Technician) objIs.readObject();
    					System.out.println("Technician Record received");
    					technician.create();
    					objOs.writeObject(true);
//    					//Call method to find the student based on the id number
//    					stuObj = findStudentById(stuId);
////    					//viewStudentRecords(stuId);
//    					objOs.writeObject(stuObj);
//    					objOs.writeObject(true);
    				}
    			} catch (ClassNotFoundException ex) {
    				ex.printStackTrace();
    			} catch (ClassCastException ex) {
    				ex.printStackTrace();
    			}
                this.closeConnection();
            }
        } catch (EOFException ex) {
			System.out.println("Client has terminated its connection with server");
			ex.printStackTrace();
        } catch (IOException e) {
            System.err.println("Error while waiting for requests: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
}
