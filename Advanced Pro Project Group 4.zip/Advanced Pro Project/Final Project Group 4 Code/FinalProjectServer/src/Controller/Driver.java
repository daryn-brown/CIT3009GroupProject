package Controller;

import java.util.Scanner;

import Models.Customer;
import Models.Representative;
import Models.Technician;
import Models.User;
//import Models.User;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		new Server();
		
	    }

}
